# 🦅 AVFenix Starter Kit (AFXC v10.0.0)

Plantilla inicial lista para producción con AVFenix Types, General.JS y AFXC.
